# 🎮 Guia de Implementação do Jogo Principal

## Visão Geral

O jogo principal (`MainSnakeGame.ts`) é o componente mais complexo do projeto. Este guia explica como implementá-lo.

## Estrutura Básica

```typescript
// MainSnakeGame.ts
import { GameBase } from './GameBase'; // Herdar de classe base
import type { GamePhase, Food, Direction } from './types';
import { getFoodDiscoverySystem } from './FoodDiscoverySystem';

export class MainSnakeGame {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  
  // Estado do jogo
  private snake: {x: number, y: number}[] = [];
  private direction: Direction = 'right';
  private currentPhase: GamePhase;
  private currentFood: Food | null = null;
  private foodPosition: {x: number, y: number} | null = null;
  
  // Sistema
  private calories: number = 300;
  private score: number = 0;
  private phaseTime: number = 0;
  
  constructor(canvas: HTMLCanvasElement, phases: GamePhase[]) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.currentPhase = phases[0];
    
    this.setupGame();
    this.setupInput();
  }
  
  // Métodos principais...
}
```

## 1. Setup Inicial

```typescript
private setupGame(): void {
  // Calcular grid
  const cellSize = Math.min(
    this.canvas.width / this.currentPhase.cols,
    (this.canvas.height - HUD_HEIGHT) / this.currentPhase.rows
  );
  
  // Posicionar cobra no centro
  const centerX = Math.floor(this.currentPhase.cols / 2);
  const centerY = Math.floor(this.currentPhase.rows / 2);
  
  this.snake = [
    { x: centerX, y: centerY },
    { x: centerX - 1, y: centerY },
    { x: centerX - 2, y: centerY }
  ];
  
  // Colocar primeiro alimento
  this.spawnFood();
}
```

## 2. Sistema de Alimentos

```typescript
private spawnFood(): void {
  // Escolher alimento aleatório da fase atual
  const foodNames = this.currentPhase.foodList;
  const randomName = foodNames[Math.floor(Math.random() * foodNames.length)];
  this.currentFood = this.getFoodByName(randomName);
  
  // Posição aleatória (não ocupada pela cobra)
  do {
    this.foodPosition = {
      x: Math.floor(Math.random() * this.currentPhase.cols),
      y: Math.floor(Math.random() * this.currentPhase.rows)
    };
  } while (this.isSnakeAt(this.foodPosition));
}

private eatFood(): void {
  if (!this.currentFood) return;
  
  // Adicionar calorias
  this.calories += this.currentFood.energia_kcal;
  this.score += this.currentFood.energia_kcal;
  
  // Sistema de descoberta
  const discovery = getFoodDiscoverySystem();
  const isNew = discovery.discoverFood(this.currentFood.nome);
  
  if (isNew) {
    this.emit('foodDiscovered', this.currentFood);
  }
  
  // Crescer cobra baseado em calorias
  const newSegments = Math.floor(this.calories / 100) - this.snake.length + 3;
  for (let i = 0; i < newSegments; i++) {
    const tail = this.snake[this.snake.length - 1];
    this.snake.push({ ...tail });
  }
  
  // Próximo alimento
  this.spawnFood();
}
```

## 3. Movimento da Cobra

```typescript
private update(deltaTime: number): void {
  // Queima de calorias passiva
  this.calories -= CALORIES_PER_SECOND * deltaTime;
  
  // Mover cabeça
  const head = { ...this.snake[0] };
  
  switch (this.direction) {
    case 'up': head.y--; break;
    case 'down': head.y++; break;
    case 'left': head.x--; break;
    case 'right': head.x++; break;
  }
  
  // Adicionar nova cabeça
  this.snake.unshift(head);
  
  // Verificar se comeu
  if (this.foodPosition &&
      head.x === this.foodPosition.x &&
      head.y === this.foodPosition.y) {
    this.eatFood();
  } else {
    // Remover cauda se não comeu
    this.snake.pop();
  }
  
  // Verificar colisões
  if (this.checkCollision()) {
    this.gameOver();
  }
  
  // Ajustar tamanho da cobra
  this.adjustSnakeSize();
  
  // Atualizar tempo da fase
  this.phaseTime += deltaTime;
  if (this.phaseTime >= this.currentPhase.duration) {
    this.showPhaseMenu();
  }
}

private adjustSnakeSize(): void {
  const desiredSize = Math.max(1, Math.floor(this.calories / 100));
  
  while (this.snake.length > desiredSize) {
    this.snake.pop();
  }
}
```

## 4. Renderização

```typescript
private render(): void {
  // Limpar canvas
  this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  
  // Desenhar HUD
  this.drawHUD();
  
  // Desenhar grid
  this.drawGrid();
  
  // Desenhar alimento
  if (this.foodPosition && this.currentFood) {
    this.drawFood(this.foodPosition, this.currentFood);
  }
  
  // Desenhar cobra
  this.drawSnake();
}

private drawHUD(): void {
  const y = 20;
  
  this.ctx.fillStyle = '#1f2937';
  this.ctx.fillRect(0, 0, this.canvas.width, HUD_HEIGHT);
  
  // Pontuação
  this.ctx.fillStyle = 'white';
  this.ctx.font = 'bold 24px Arial';
  this.ctx.fillText(`Energia: ${this.score} kcal`, 20, y + 30);
  
  // Barra de calorias
  const barWidth = 300;
  const barX = this.canvas.width / 2 - barWidth / 2;
  const barY = y + 20;
  
  this.ctx.fillStyle = '#374151';
  this.ctx.fillRect(barX, barY, barWidth, 14);
  
  const fillWidth = (this.calories / CALORIES_MAX) * barWidth;
  this.ctx.fillStyle = '#f97316';
  this.ctx.fillRect(barX, barY, fillWidth, 14);
  
  // Texto calorias
  this.ctx.fillStyle = 'white';
  this.ctx.font = '14px Arial';
  this.ctx.fillText(
    `${Math.floor(this.calories)}/${CALORIES_MAX} kcal`,
    this.canvas.width / 2,
    barY + 30
  );
}

private drawFood(pos: {x: number, y: number}, food: Food): void {
  const x = this.gridOffsetX + pos.x * this.cellSize;
  const y = this.gridOffsetY + pos.y * this.cellSize;
  
  // Cor baseada na saúde do alimento
  this.ctx.fillStyle = COLOR_MAP[food.cor];
  this.ctx.fillRect(x, y, this.cellSize, this.cellSize);
  
  // Tentar carregar imagem (se disponível)
  // ...
}

private drawSnake(): void {
  for (let i = 0; i < this.snake.length; i++) {
    const segment = this.snake[i];
    const x = this.gridOffsetX + segment.x * this.cellSize;
    const y = this.gridOffsetY + segment.y * this.cellSize;
    
    if (i === 0) {
      // Cabeça
      this.ctx.fillStyle = '#BE4B00';
    } else {
      // Corpo
      this.ctx.fillStyle = '#A03C00';
    }
    
    this.ctx.fillRect(x + 1, y + 1, this.cellSize - 2, this.cellSize - 2);
  }
}
```

## 5. Input

```typescript
private setupInput(): void {
  window.addEventListener('keydown', (e) => {
    switch (e.key) {
      case 'ArrowUp':
        if (this.direction !== 'down') this.direction = 'up';
        break;
      case 'ArrowDown':
        if (this.direction !== 'up') this.direction = 'down';
        break;
      case 'ArrowLeft':
        if (this.direction !== 'right') this.direction = 'left';
        break;
      case 'ArrowRight':
        if (this.direction !== 'left') this.direction = 'right';
        break;
      case 'c':
      case 'C':
        this.emit('catalogRequested');
        break;
    }
  });
}
```

## 6. Transição de Fases

```typescript
private showPhaseMenu(): void {
  this.state = 'menu';
  
  const options = [];
  
  if (this.currentPhaseIndex < this.phases.length - 1) {
    options.push({
      text: 'Treino (Mini-jogo)',
      action: () => this.startMinigame()
    });
    
    const nextPhase = this.phases[this.currentPhaseIndex + 1];
    options.push({
      text: nextPhase.name,
      action: () => this.nextPhase()
    });
  } else {
    options.push({
      text: 'Dormir',
      action: () => this.endDay()
    });
  }
  
  this.emit('menuShown', options);
}

private nextPhase(): void {
  this.currentPhaseIndex++;
  this.currentPhase = this.phases[this.currentPhaseIndex];
  this.phaseTime = 0;
  
  // Reposicionar cobra no centro da nova grid
  this.setupGame();
  
  this.state = 'playing';
}

private startMinigame(): void {
  // Escolher mini-jogo aleatório
  const games = ['jump', 'balance', 'run'];
  const chosen = games[Math.floor(Math.random() * games.length)];
  
  this.emit('minigameRequested', {
    type: chosen,
    calories: this.calories
  });
}
```

## 7. Game Over

```typescript
private checkCollision(): boolean {
  const head = this.snake[0];
  
  // Colisão com paredes
  if (head.x < 0 || head.x >= this.currentPhase.cols ||
      head.y < 0 || head.y >= this.currentPhase.rows) {
    return true;
  }
  
  // Colisão com próprio corpo
  for (let i = 1; i < this.snake.length; i++) {
    if (head.x === this.snake[i].x && head.y === this.snake[i].y) {
      return true;
    }
  }
  
  // Calorias fora dos limites
  if (this.calories <= 0 || this.calories >= CALORIES_MAX) {
    return true;
  }
  
  return false;
}

private gameOver(): void {
  this.state = 'gameOver';
  this.emit('gameOver', {
    score: this.score,
    calories: this.calories,
    day: this.currentDay
  });
}
```

## 8. Eventos (EventEmitter)

```typescript
private listeners: Map<string, Function[]> = new Map();

public on(event: string, callback: Function): void {
  if (!this.listeners.has(event)) {
    this.listeners.set(event, []);
  }
  this.listeners.get(event)!.push(callback);
}

private emit(event: string, data?: any): void {
  const callbacks = this.listeners.get(event);
  if (callbacks) {
    callbacks.forEach(cb => cb(data));
  }
}
```

## Integração com Vue

```vue
<script setup>
import { onMounted, ref } from 'vue';
import { MainSnakeGame } from '@/games/MainSnakeGame';
import phases from '@/data/phases.json';

const canvas = ref(null);
let game = null;

onMounted(() => {
  game = new MainSnakeGame(canvas.value, phases);
  
  game.on('foodDiscovered', (food) => {
    // Mostrar toast
  });
  
  game.on('gameOver', (result) => {
    // Mostrar tela de game over
  });
  
  game.on('catalogRequested', () => {
    // Abrir catálogo
  });
  
  game.start();
});
</script>
```

## Próximos Passos

1. Implementar classe `MainSnakeGame` completa
2. Adicionar transições suaves
3. Implementar sistema de sons
4. Adicionar partículas ao comer
5. Melhorar renderização com sprites
6. Adicionar animações de transição
7. Implementar pause/resume
8. Adicionar tutorial

## Recursos

- Veja `types.ts` para todas as interfaces
- Consulte `FoodDiscoverySystem.ts` para integração
- Leia `phases.json` para estrutura das fases
- Examine `foods.json` para dados dos alimentos

Boa implementação! 🎮🐍
