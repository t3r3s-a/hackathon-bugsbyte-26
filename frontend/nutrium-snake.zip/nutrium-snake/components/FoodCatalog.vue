<template>
  <div class="food-catalog">
    <!-- Header do Catálogo -->
    <div class="catalog-header">
      <div class="header-content">
        <h1 class="catalog-title">
          📚 Caderneta Alimentar
        </h1>
        <div class="discovery-stats">
          <span class="stat-item">
            <span class="stat-icon">🔍</span>
            {{ discoveredCount }} / {{ totalFoods }} descobertos
          </span>
          <span class="stat-item">
            <span class="stat-icon">📊</span>
            {{ progressPercentage }}%
          </span>
        </div>
      </div>
      
      <button @click="$emit('close')" class="close-button">
        ✕
      </button>
    </div>

    <!-- Filtros -->
    <div class="filters">
      <button
        v-for="color in filters"
        :key="color"
        @click="selectedFilter = color"
        :class="['filter-btn', { active: selectedFilter === color }]"
        :style="{ borderColor: getColorForFilter(color) }"
      >
        {{ color === 'all' ? 'Todos' : getFilterLabel(color) }}
      </button>
    </div>

    <!-- Grid de Alimentos -->
    <div class="foods-grid">
      <div
        v-for="food in filteredFoods"
        :key="food.nome"
        @click="selectFood(food)"
        :class="['food-card', { discovered: isDiscovered(food.nome), locked: !isDiscovered(food.nome) }]"
      >
        <div v-if="!isDiscovered(food.nome)" class="locked-overlay">
          <span class="lock-icon">🔒</span>
          <span class="lock-text">Não descoberto</span>
        </div>
        
        <div v-else class="food-content">
          <!-- Imagem do alimento -->
          <div class="food-image">
            <img
              v-if="getFoodImage(food.nome)"
              :src="getFoodImage(food.nome)"
              :alt="food.nome"
              @error="handleImageError"
            />
            <div v-else class="food-placeholder" :style="{ background: COLOR_MAP[food.cor] }">
              🍽️
            </div>
          </div>
          
          <!-- Info básica -->
          <div class="food-info">
            <h3 class="food-name">{{ food.nome }}</h3>
            <div class="food-color-indicator" :style="{ background: COLOR_MAP[food.cor] }"></div>
            <div class="food-calories">{{ food.energia_kcal }} kcal</div>
          </div>
          
          <!-- Times eaten badge -->
          <div v-if="getTimesEaten(food.nome) > 1" class="times-eaten-badge">
            × {{ getTimesEaten(food.nome) }}
          </div>
        </div>
      </div>

      <!-- Placeholders para alimentos não descobertos -->
      <div
        v-for="i in placeholderCount"
        :key="`placeholder-${i}`"
        class="food-card locked"
      >
        <div class="locked-overlay">
          <span class="lock-icon">❓</span>
          <span class="lock-text">???</span>
        </div>
      </div>
    </div>

    <!-- Modal de detalhes do alimento -->
    <FoodDetailModal
      v-if="selectedFood"
      :food="selectedFood"
      :discovery="getDiscovery(selectedFood.nome)"
      @close="selectedFood = null"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { getFoodDiscoverySystem } from '../games/FoodDiscoverySystem';
import FoodDetailModal from './FoodDetailModal.vue';
import type { Food } from '../games/types';
import { COLOR_MAP } from '../games/types';

interface Props {
  foods: Food[];
}

const props = defineProps<Props>();
const emit = defineEmits<{
  close: [];
}>();

const discoverySystem = getFoodDiscoverySystem();
const selectedFilter = ref<string>('all');
const selectedFood = ref<Food | null>(null);

const filters = ['all', 'verde', 'amarelo', 'laranja', 'vermelho'];

const discoveredCount = computed(() => {
  return props.foods.filter(f => discoverySystem.isDiscovered(f.nome)).length;
});

const totalFoods = computed(() => props.foods.length);

const progressPercentage = computed(() => {
  return Math.round((discoveredCount.value / totalFoods.value) * 100);
});

const filteredFoods = computed(() => {
  if (selectedFilter.value === 'all') {
    return props.foods;
  }
  return props.foods.filter(f => f.cor === selectedFilter.value);
});

const placeholderCount = computed(() => {
  const discovered = filteredFoods.value.filter(f => discoverySystem.isDiscovered(f.nome)).length;
  const total = filteredFoods.value.length;
  return Math.max(0, Math.min(12 - discovered, total - discovered));
});

function isDiscovered(foodName: string): boolean {
  return discoverySystem.isDiscovered(foodName);
}

function getDiscovery(foodName: string) {
  return discoverySystem.getDiscovery(foodName);
}

function getTimesEaten(foodName: string): number {
  const discovery = discoverySystem.getDiscovery(foodName);
  return discovery?.timesEaten || 0;
}

function selectFood(food: Food) {
  if (isDiscovered(food.nome)) {
    selectedFood.value = food;
  }
}

function getFoodImage(foodName: string): string {
  // Assume que as imagens estão em /assets/foods/
  return `/assets/foods/${foodName}.png`;
}

function handleImageError(e: Event) {
  // Se a imagem falhar ao carregar, esconde
  (e.target as HTMLImageElement).style.display = 'none';
}

function getColorForFilter(filter: string): string {
  if (filter === 'all') return '#6366F1';
  return COLOR_MAP[filter as keyof typeof COLOR_MAP] || '#888';
}

function getFilterLabel(color: string): string {
  const labels: Record<string, string> = {
    verde: '🟢 Saudável',
    amarelo: '🟡 Moderado',
    laranja: '🟠 Ocasional',
    vermelho: '🔴 Raro'
  };
  return labels[color] || color;
}
</script>

<style scoped>
.food-catalog {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  z-index: 1000;
  overflow-y: auto;
  padding: 2rem;
}

.catalog-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: rgba(255, 255, 255, 0.95);
  padding: 1.5rem 2rem;
  border-radius: 16px;
  margin-bottom: 2rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.header-content {
  flex: 1;
}

.catalog-title {
  font-size: 2rem;
  margin: 0 0 0.5rem 0;
  color: #1f2937;
}

.discovery-stats {
  display: flex;
  gap: 2rem;
  font-size: 1.1rem;
  color: #6b7280;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.stat-icon {
  font-size: 1.3rem;
}

.close-button {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  border: none;
  background: #ef4444;
  color: white;
  font-size: 1.5rem;
  cursor: pointer;
  transition: all 0.3s;
}

.close-button:hover {
  background: #dc2626;
  transform: rotate(90deg);
}

.filters {
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
  flex-wrap: wrap;
}

.filter-btn {
  padding: 0.75rem 1.5rem;
  border: 3px solid transparent;
  border-radius: 24px;
  background: rgba(255, 255, 255, 0.9);
  color: #1f2937;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s;
}

.filter-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.filter-btn.active {
  background: white;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}

.foods-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 1.5rem;
}

.food-card {
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  padding: 1rem;
  cursor: pointer;
  transition: all 0.3s;
  position: relative;
  overflow: hidden;
  min-height: 250px;
  display: flex;
  flex-direction: column;
}

.food-card.discovered:hover {
  transform: translateY(-8px);
  box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
}

.food-card.locked {
  cursor: not-allowed;
  opacity: 0.6;
}

.locked-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.7);
  color: white;
}

.lock-icon {
  font-size: 3rem;
  margin-bottom: 0.5rem;
}

.lock-text {
  font-size: 1rem;
  font-weight: 600;
}

.food-content {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.food-image {
  width: 100%;
  height: 140px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 1rem;
  border-radius: 12px;
  overflow: hidden;
}

.food-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.food-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 4rem;
  border-radius: 12px;
}

.food-info {
  flex: 1;
}

.food-name {
  font-size: 1.1rem;
  font-weight: 600;
  color: #1f2937;
  margin: 0 0 0.5rem 0;
}

.food-color-indicator {
  width: 40px;
  height: 4px;
  border-radius: 2px;
  margin-bottom: 0.5rem;
}

.food-calories {
  font-size: 0.9rem;
  color: #6b7280;
  font-weight: 600;
}

.times-eaten-badge {
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: #f59e0b;
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-weight: bold;
  font-size: 0.85rem;
}

/* Animação de entrada */
.food-card {
  animation: fadeInUp 0.4s ease-out;
}

@keyframes fadeInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
