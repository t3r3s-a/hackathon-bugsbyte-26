<template>
  <div id="app">
    <!-- Botão do Catálogo (flutuante) -->
    <button
      v-if="!showCatalog"
      @click="showCatalog = true"
      class="catalog-button"
      title="Abrir Caderneta Alimentar (tecla C)"
    >
      📚 Catálogo
      <span v-if="newDiscoveriesCount > 0" class="badge">
        +{{ newDiscoveriesCount }}
      </span>
    </button>

    <!-- Jogo Principal -->
    <GameContainer
      v-if="!showCatalog"
      :initial-calories="playerStats.calories"
      @food-eaten="handleFoodEaten"
      @game-end="handleGameEnd"
      @calories-change="updateCalories"
    />

    <!-- Catálogo de Alimentos -->
    <FoodCatalog
      v-if="showCatalog"
      :foods="allFoods"
      @close="showCatalog = false"
    />

    <!-- Toast de Descoberta -->
    <FoodDiscoveryToast
      v-if="discoveredFood"
      :food-name="discoveredFood.nome"
      :description="discoveredFood.descricao"
      :color="discoveredFood.cor"
      :duration="5000"
      @close="handleToastClose"
    />

    <!-- Painel de Estatísticas (opcional) -->
    <div v-if="showStats && !showCatalog" class="stats-panel">
      <h3>📊 Estatísticas</h3>
      <div class="stat">
        <span class="stat-label">Dia:</span>
        <span class="stat-value">{{ playerStats.day }}</span>
      </div>
      <div class="stat">
        <span class="stat-label">Pontuação:</span>
        <span class="stat-value">{{ playerStats.score }}</span>
      </div>
      <div class="stat">
        <span class="stat-label">Calorias:</span>
        <span class="stat-value">{{ playerStats.calories }}</span>
      </div>
      <div class="stat">
        <span class="stat-label">Alimentos descobertos:</span>
        <span class="stat-value">
          {{ playerStats.foodsDiscovered }}/{{ allFoods.length }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted, onUnmounted, computed } from 'vue';
import GameContainer from './components/GameContainer.vue';
import FoodCatalog from './components/FoodCatalog.vue';
import FoodDiscoveryToast from './components/FoodDiscoveryToast.vue';
import { getFoodDiscoverySystem } from './games/FoodDiscoverySystem';
import allFoodsData from './data/foods.json';
import type { Food } from './games/types';

// Dados
const allFoods = allFoodsData as Food[];
const discoverySystem = getFoodDiscoverySystem();

// Estado
const showCatalog = ref(false);
const showStats = ref(true);
const discoveredFood = ref<Food | null>(null);
const newDiscoveriesCount = ref(0);

// Estatísticas do jogador
const playerStats = reactive({
  day: 1,
  score: 0,
  calories: 300,
  foodsDiscovered: 0,
  gamesPlayed: 0
});

// Inicialização
onMounted(() => {
  loadPlayerStats();
  updateDiscoveryCount();
  
  // Atalho de teclado para abrir catálogo
  window.addEventListener('keydown', handleKeyPress);
});

onUnmounted(() => {
  window.removeEventListener('keydown', handleKeyPress);
});

// Handlers
function handleFoodEaten(food: Food) {
  const isNew = discoverySystem.discoverFood(food.nome);
  
  if (isNew) {
    // Nova descoberta!
    discoveredFood.value = food;
    newDiscoveriesCount.value++;
    playerStats.foodsDiscovered++;
    
    // Salvar estatísticas
    savePlayerStats();
    
    // Som de descoberta (opcional)
    playDiscoverySound();
  }
}

function handleToastClose() {
  discoveredFood.value = null;
  // Resetar contador de novas descobertas após um tempo
  setTimeout(() => {
    newDiscoveriesCount.value = 0;
  }, 1000);
}

function handleGameEnd(result: { success: boolean; score: number }) {
  if (result.success) {
    playerStats.day++;
    playerStats.score += result.score;
  } else {
    playerStats.day = 1;
    playerStats.score = 0;
  }
  
  playerStats.gamesPlayed++;
  savePlayerStats();
}

function updateCalories(newCalories: number) {
  playerStats.calories = newCalories;
}

function updateDiscoveryCount() {
  playerStats.foodsDiscovered = discoverySystem.getTotalDiscovered();
}

function handleKeyPress(e: KeyboardEvent) {
  // Tecla 'C' para abrir catálogo
  if (e.key === 'c' || e.key === 'C') {
    if (!discoveredFood.value) { // Não abrir se toast estiver visível
      showCatalog.value = !showCatalog.value;
    }
  }
  
  // Tecla 'ESC' para fechar catálogo
  if (e.key === 'Escape' && showCatalog.value) {
    showCatalog.value = false;
  }
}

// Persistência
function savePlayerStats() {
  try {
    localStorage.setItem('nutrium_snake_stats', JSON.stringify(playerStats));
  } catch (error) {
    console.error('Erro ao salvar estatísticas:', error);
  }
}

function loadPlayerStats() {
  try {
    const saved = localStorage.getItem('nutrium_snake_stats');
    if (saved) {
      const data = JSON.parse(saved);
      Object.assign(playerStats, data);
    }
  } catch (error) {
    console.error('Erro ao carregar estatísticas:', error);
  }
}

// Som (opcional)
function playDiscoverySound() {
  // Implementar som aqui se desejar
  // const audio = new Audio('/sounds/discovery.mp3');
  // audio.play().catch(() => {});
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  overflow: hidden;
}

#app {
  width: 100vw;
  height: 100vh;
  position: relative;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* Botão flutuante do catálogo */
.catalog-button {
  position: fixed;
  bottom: 20px;
  right: 20px;
  padding: 1rem 2rem;
  font-size: 1.2rem;
  font-weight: bold;
  background: linear-gradient(135deg, #4ade80 0%, #22c55e 100%);
  color: white;
  border: none;
  border-radius: 50px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
  cursor: pointer;
  transition: all 0.3s ease;
  z-index: 900;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.catalog-button:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.4);
}

.catalog-button .badge {
  background: #ef4444;
  color: white;
  padding: 0.25rem 0.5rem;
  border-radius: 12px;
  font-size: 0.9rem;
  font-weight: bold;
  animation: pulse 1s infinite;
}

@keyframes pulse {
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.1);
  }
}

/* Painel de estatísticas */
.stats-panel {
  position: fixed;
  top: 20px;
  right: 20px;
  background: rgba(255, 255, 255, 0.95);
  border-radius: 16px;
  padding: 1.5rem;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
  min-width: 250px;
  z-index: 100;
}

.stats-panel h3 {
  margin: 0 0 1rem 0;
  font-size: 1.3rem;
  color: #1f2937;
}

.stat {
  display: flex;
  justify-content: space-between;
  padding: 0.5rem 0;
  border-bottom: 1px solid #e5e7eb;
}

.stat:last-child {
  border-bottom: none;
}

.stat-label {
  color: #6b7280;
  font-size: 0.95rem;
}

.stat-value {
  color: #1f2937;
  font-weight: bold;
  font-size: 1.1rem;
}

/* Instruções (tooltip) */
.catalog-button::before {
  content: "Pressiona C";
  position: absolute;
  bottom: calc(100% + 10px);
  right: 0;
  background: rgba(0, 0, 0, 0.8);
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  font-size: 0.85rem;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.3s;
}

.catalog-button:hover::before {
  opacity: 1;
}

/* Responsividade */
@media (max-width: 768px) {
  .stats-panel {
    top: 10px;
    right: 10px;
    padding: 1rem;
    min-width: 200px;
  }
  
  .catalog-button {
    bottom: 10px;
    right: 10px;
    padding: 0.75rem 1.5rem;
    font-size: 1rem;
  }
}
</style>
