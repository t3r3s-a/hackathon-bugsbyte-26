# 🚀 Guia de Início Rápido - Nutrium Snake

## Instalação Rápida (5 minutos)

### 1. Copiar Ficheiros

```bash
# Copie toda a pasta para o seu projeto Vue
cp -r nutrium-snake/ seu-projeto/src/
```

### 2. Instalar Dependências

```bash
npm install
```

### 3. Usar no Seu App

```vue
<!-- App.vue -->
<template>
  <div>
    <GameContainer @food-eaten="handleDiscovery" />
    <FoodCatalog v-if="showCatalog" :foods="foods" />
  </div>
</template>

<script setup>
import GameContainer from '@/components/GameContainer.vue';
import FoodCatalog from '@/components/FoodCatalog.vue';
import foods from '@/data/foods.json';
</script>
```

Pronto! 🎉

---

## Funcionalidades Principais

### 1. Sistema de Descoberta

```typescript
import { getFoodDiscoverySystem } from '@/games/FoodDiscoverySystem';

const discovery = getFoodDiscoverySystem();

// Marcar alimento como descoberto
const isNew = discovery.discoverFood('Maçã'); // true na primeira vez

// Verificar se foi descoberto
const hasIt = discovery.isDiscovered('Maçã'); // boolean

// Total descoberto
const total = discovery.getTotalDiscovered(); // número
```

### 2. Catálogo de Alimentos

```vue
<FoodCatalog
  :foods="allFoods"
  @close="closeCatalog"
/>
```

Mostra:
- ✅ Alimentos descobertos (desbloqueados)
- 🔒 Alimentos não descobertos (bloqueados)
- 📊 Progresso geral
- 🎨 Filtros por cor

### 3. Toast de Descoberta

```vue
<FoodDiscoveryToast
  v-if="newFood"
  :food-name="newFood.nome"
  :description="newFood.descricao"
  :color="newFood.cor"
  @close="newFood = null"
/>
```

Aparece automaticamente quando descobre novo alimento!

### 4. Modal de Detalhes

Quando clica num alimento no catálogo, mostra:
- 📸 Imagem
- 📊 Barras nutricionais (0-5)
- 🌟 Avaliação (estrelas)
- 🔬 Valores detalhados
- ⚠️ Alergénios
- 📝 Descrição educacional

---

## Exemplos de Código

### Exemplo 1: Básico

```vue
<template>
  <GameContainer />
</template>

<script setup>
import GameContainer from '@/components/GameContainer.vue';
</script>
```

### Exemplo 2: Com Catálogo

```vue
<template>
  <div>
    <button @click="show = true">Ver Catálogo</button>
    <GameContainer @food-eaten="handleFood" />
    <FoodCatalog v-if="show" :foods="foods" @close="show = false" />
  </div>
</template>

<script setup>
import { ref } from 'vue';
import GameContainer from '@/components/GameContainer.vue';
import FoodCatalog from '@/components/FoodCatalog.vue';
import foods from '@/data/foods.json';

const show = ref(false);

function handleFood(food) {
  console.log('Comeu:', food.nome);
}
</script>
```

### Exemplo 3: Com Descoberta

```vue
<template>
  <div>
    <GameContainer @food-eaten="handleFood" />
    
    <!-- Toast de descoberta -->
    <FoodDiscoveryToast
      v-if="discovered"
      :food-name="discovered.nome"
      :description="discovered.descricao"
      :color="discovered.cor"
      @close="discovered = null"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { getFoodDiscoverySystem } from '@/games/FoodDiscoverySystem';
import GameContainer from '@/components/GameContainer.vue';
import FoodDiscoveryToast from '@/components/FoodDiscoveryToast.vue';

const discovered = ref(null);
const discovery = getFoodDiscoverySystem();

function handleFood(food) {
  const isNew = discovery.discoverFood(food.nome);
  
  if (isNew) {
    discovered.value = food; // Mostra toast!
  }
}
</script>
```

### Exemplo 4: Completo (com tudo)

```vue
<template>
  <div id="app">
    <!-- Botão catálogo -->
    <button @click="showCatalog = true" class="catalog-btn">
      📚 Catálogo
    </button>

    <!-- Jogo -->
    <GameContainer
      v-if="!showCatalog"
      @food-eaten="handleFood"
    />

    <!-- Catálogo -->
    <FoodCatalog
      v-if="showCatalog"
      :foods="foods"
      @close="showCatalog = false"
    />

    <!-- Toast -->
    <FoodDiscoveryToast
      v-if="discovered"
      :food-name="discovered.nome"
      :description="discovered.descricao"
      :color="discovered.cor"
      @close="discovered = null"
    />

    <!-- Stats -->
    <div class="stats">
      Descobertos: {{ totalDiscovered }}/{{ foods.length }}
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';
import { getFoodDiscoverySystem } from '@/games/FoodDiscoverySystem';
import GameContainer from '@/components/GameContainer.vue';
import FoodCatalog from '@/components/FoodCatalog.vue';
import FoodDiscoveryToast from '@/components/FoodDiscoveryToast.vue';
import foods from '@/data/foods.json';

const showCatalog = ref(false);
const discovered = ref(null);
const discovery = getFoodDiscoverySystem();

const totalDiscovered = computed(() => discovery.getTotalDiscovered());

function handleFood(food) {
  const isNew = discovery.discoverFood(food.nome);
  if (isNew) discovered.value = food;
}
</script>

<style>
.catalog-btn {
  position: fixed;
  bottom: 20px;
  right: 20px;
  padding: 1rem 2rem;
  background: #4ade80;
  color: white;
  border: none;
  border-radius: 50px;
  font-size: 1.2rem;
  cursor: pointer;
  z-index: 1000;
}

.stats {
  position: fixed;
  top: 20px;
  right: 20px;
  background: white;
  padding: 1rem;
  border-radius: 8px;
}
</style>
```

---

## Atalhos de Teclado

| Tecla | Ação |
|-------|------|
| **C** | Abrir/fechar catálogo |
| **ESC** | Fechar modal/catálogo |
| **← → ↑ ↓** | Mover cobra |
| **Espaço** | Saltar (mini-jogo) |

---

## Estrutura de Dados

### Food (Alimento)

```typescript
interface Food {
  nome: string;              // "Maçã"
  energia_kcal: number;      // 52
  proteina_g: number;        // 0.3
  hidratos_g: number;        // 14
  acucares_g: number;        // 10
  lipidos_g: number;         // 0.2
  agua_g: number;            // 86
  vitamina_c_mg: number;     // 4.6
  vitamina_a_ug: number;     // 3
  potassio_mg: number;       // 107
  calcio_mg: number;         // 6
  ferro_mg: number;          // 0.1
  alergias: string[];        // ["FRUTAS"]
  descricao: string;         // Texto educacional
  cor: 'verde' | 'amarelo' | 'laranja' | 'vermelho';
}
```

### Cores de Saúde

- 🟢 **Verde**: Saudável (come regularmente)
- 🟡 **Amarelo**: Moderado (com cautela)
- 🟠 **Laranja**: Ocasional (raramente)
- 🔴 **Vermelho**: Evitar (muito raramente)

---

## Personalizações Rápidas

### Mudar Cores do Catálogo

```vue
<!-- FoodCatalog.vue -->
<style>
.food-catalog {
  background: linear-gradient(135deg, #sua-cor-1, #sua-cor-2);
}
</style>
```

### Mudar Duração do Toast

```vue
<FoodDiscoveryToast
  :duration="3000"
  <!-- 3 segundos em vez de 5 -->
/>
```

### Desativar Sons

Comentar linha no `App.vue`:
```typescript
// playDiscoverySound(); // Som desativado
```

### Resetar Descobertas (Debug)

```typescript
import { getFoodDiscoverySystem } from '@/games/FoodDiscoverySystem';

getFoodDiscoverySystem().resetAllDiscoveries();
```

---

## Troubleshooting Rápido

### ❌ Catálogo não abre
**Solução**: Verifique se importou o componente corretamente

### ❌ Imagens não aparecem
**Solução**: Coloque imagens em `public/assets/foods/`

### ❌ Descobertas não salvam
**Solução**: localStorage precisa estar ativo (sem modo privado)

### ❌ Toast não fecha
**Solução**: Certifique-se de lidar com o evento `@close`

---

## Próximos Passos

1. ✅ Instale e teste o exemplo básico
2. 🎨 Personalize cores e estilos
3. 📊 Adicione estatísticas extras
4. 🔊 Adicione sons (opcional)
5. 🌐 Torne responsivo
6. 📱 Teste em mobile

---

## Recursos Úteis

- 📖 **README completo**: `README.md`
- 🎮 **Controles**: Ver secção de controles
- 💾 **Dados**: `data/foods.json`
- 🎨 **Estilos**: Cada componente tem `<style scoped>`

---

**Dica**: Use `console.log()` para debug:

```typescript
function handleFood(food) {
  console.log('Alimento:', food);
  console.log('Descoberto?', discovery.isDiscovered(food.nome));
}
```

Bom jogo! 🐍🍎✨
