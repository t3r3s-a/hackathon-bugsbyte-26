<template>
  <div class="modal-overlay" @click="$emit('close')">
    <div class="modal-content" @click.stop>
      <!-- Header -->
      <div class="modal-header">
        <h2 class="food-title">{{ food.nome }}</h2>
        <button @click="$emit('close')" class="close-btn">✕</button>
      </div>

      <!-- Imagem e info básica -->
      <div class="food-main-info">
        <div class="food-image-large">
          <img
            v-if="getFoodImage()"
            :src="getFoodImage()"
            :alt="food.nome"
            @error="imageError = true"
          />
          <div v-if="imageError" class="image-placeholder" :style="{ background: COLOR_MAP[food.cor] }">
            🍽️
          </div>
        </div>

        <div class="food-quick-stats">
          <div class="stat-box">
            <span class="stat-value">{{ food.energia_kcal }}</span>
            <span class="stat-label">kcal</span>
          </div>
          <div class="stat-box">
            <span class="stat-value">{{ discovery?.timesEaten || 0 }}</span>
            <span class="stat-label">vezes comido</span>
          </div>
          <div class="stat-box rating-box">
            <div class="stars">
              <span v-for="i in 5" :key="i" class="star" :class="{ filled: i <= rating }">
                ★
              </span>
            </div>
            <span class="stat-label">Avaliação</span>
          </div>
        </div>
      </div>

      <!-- Descrição -->
      <div class="description-section">
        <p class="description-text">{{ food.descricao }}</p>
      </div>

      <!-- Barras Nutricionais -->
      <div class="nutrition-section">
        <h3 class="section-title">📊 Informação Nutricional</h3>
        
        <div class="nutrition-bars">
          <div class="nutrition-row">
            <span class="nutrition-label">💪 Proteínas</span>
            <div class="bar-container">
              <div
                class="bar-fill protein"
                :style="{ width: `${(nutritionBars.protein / 5) * 100}%` }"
              ></div>
            </div>
            <span class="nutrition-value">{{ nutritionBars.protein }}/5</span>
          </div>

          <div class="nutrition-row">
            <span class="nutrition-label">💧 Hidratação</span>
            <div class="bar-container">
              <div
                class="bar-fill hydration"
                :style="{ width: `${(nutritionBars.hydration / 5) * 100}%` }"
              ></div>
            </div>
            <span class="nutrition-value">{{ nutritionBars.hydration }}/5</span>
          </div>

          <div class="nutrition-row">
            <span class="nutrition-label">🔥 Calorias</span>
            <div class="bar-container">
              <div
                class="bar-fill calories"
                :style="{ width: `${(nutritionBars.calories / 5) * 100}%` }"
              ></div>
            </div>
            <span class="nutrition-value">{{ nutritionBars.calories }}/5</span>
          </div>

          <div class="nutrition-row">
            <span class="nutrition-label">🍊 Vitaminas</span>
            <div class="bar-container">
              <div
                class="bar-fill vitamins"
                :style="{ width: `${(nutritionBars.vitamins / 5) * 100}%` }"
              ></div>
            </div>
            <span class="nutrition-value">{{ nutritionBars.vitamins }}/5</span>
          </div>

          <div class="nutrition-row">
            <span class="nutrition-label">⚡ Minerais</span>
            <div class="bar-container">
              <div
                class="bar-fill minerals"
                :style="{ width: `${(nutritionBars.minerals / 5) * 100}%` }"
              ></div>
            </div>
            <span class="nutrition-value">{{ nutritionBars.minerals }}/5</span>
          </div>
        </div>
      </div>

      <!-- Detalhes Nutricionais -->
      <div class="details-section">
        <h3 class="section-title">🔬 Detalhes</h3>
        <div class="details-grid">
          <div class="detail-item">
            <span class="detail-label">Proteínas</span>
            <span class="detail-value">{{ food.proteina_g }}g</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Hidratos</span>
            <span class="detail-value">{{ food.hidratos_g }}g</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Açúcares</span>
            <span class="detail-value">{{ food.acucares_g }}g</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Lípidos</span>
            <span class="detail-value">{{ food.lipidos_g }}g</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Água</span>
            <span class="detail-value">{{ food.agua_g }}g</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Vit. C</span>
            <span class="detail-value">{{ food.vitamina_c_mg }}mg</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Vit. A</span>
            <span class="detail-value">{{ food.vitamina_a_ug }}μg</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Potássio</span>
            <span class="detail-value">{{ food.potassio_mg }}mg</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Cálcio</span>
            <span class="detail-value">{{ food.calcio_mg }}mg</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Ferro</span>
            <span class="detail-value">{{ food.ferro_mg }}mg</span>
          </div>
        </div>
      </div>

      <!-- Alergias -->
      <div v-if="food.alergias.length > 0" class="allergies-section">
        <h3 class="section-title">⚠️ Alergénios</h3>
        <div class="allergies-tags">
          <span v-for="allergy in food.alergias" :key="allergy" class="allergy-tag">
            {{ allergy }}
          </span>
        </div>
      </div>

      <!-- Info de descoberta -->
      <div v-if="discovery" class="discovery-info">
        <p class="discovery-text">
          📅 Descoberto em {{ formatDate(discovery.discoveredAt) }}
        </p>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { getFoodDiscoverySystem } from '../games/FoodDiscoverySystem';
import type { Food, FoodDiscovery } from '../games/types';
import { COLOR_MAP } from '../games/types';

interface Props {
  food: Food;
  discovery: FoodDiscovery | null;
}

const props = defineProps<Props>();
const emit = defineEmits<{
  close: [];
}>();

const imageError = ref(false);
const discoverySystem = getFoodDiscoverySystem();

const nutritionBars = computed(() => {
  return discoverySystem.calculateNutritionBars(props.food);
});

const rating = computed(() => {
  return discoverySystem.calculateRating(props.food);
});

function getFoodImage(): string {
  return `/assets/foods/${props.food.nome}.png`;
}

function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('pt-PT', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }).format(date);
}
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.75);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2000;
  padding: 2rem;
  overflow-y: auto;
}

.modal-content {
  background: white;
  border-radius: 24px;
  max-width: 700px;
  width: 100%;
  max-height: 90vh;
  overflow-y: auto;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  animation: modalAppear 0.3s ease-out;
}

@keyframes modalAppear {
  from {
    opacity: 0;
    transform: scale(0.9) translateY(20px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2rem;
  border-bottom: 2px solid #e5e7eb;
}

.food-title {
  font-size: 2rem;
  margin: 0;
  color: #1f2937;
}

.close-btn {
  width: 36px;
  height: 36px;
  border: none;
  background: #ef4444;
  color: white;
  border-radius: 50%;
  font-size: 1.5rem;
  cursor: pointer;
  transition: all 0.3s;
}

.close-btn:hover {
  background: #dc2626;
  transform: rotate(90deg);
}

.food-main-info {
  display: flex;
  gap: 2rem;
  padding: 2rem;
  border-bottom: 2px solid #e5e7eb;
}

.food-image-large {
  width: 200px;
  height: 200px;
  border-radius: 16px;
  overflow: hidden;
  flex-shrink: 0;
}

.food-image-large img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.image-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 6rem;
}

.food-quick-stats {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.stat-box {
  background: #f3f4f6;
  padding: 1rem;
  border-radius: 12px;
  text-align: center;
}

.stat-value {
  display: block;
  font-size: 2rem;
  font-weight: bold;
  color: #1f2937;
}

.stat-label {
  display: block;
  font-size: 0.9rem;
  color: #6b7280;
  margin-top: 0.25rem;
}

.rating-box {
  background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
}

.stars {
  font-size: 1.5rem;
  color: #fff;
}

.star {
  opacity: 0.3;
  transition: opacity 0.3s;
}

.star.filled {
  opacity: 1;
}

.rating-box .stat-label {
  color: white;
}

.description-section {
  padding: 2rem;
  background: #f9fafb;
}

.description-text {
  font-size: 1.1rem;
  line-height: 1.6;
  color: #374151;
  margin: 0;
}

.nutrition-section {
  padding: 2rem;
}

.section-title {
  font-size: 1.3rem;
  margin: 0 0 1.5rem 0;
  color: #1f2937;
}

.nutrition-bars {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.nutrition-row {
  display: grid;
  grid-template-columns: 140px 1fr 60px;
  gap: 1rem;
  align-items: center;
}

.nutrition-label {
  font-size: 1rem;
  font-weight: 600;
  color: #374151;
}

.bar-container {
  height: 24px;
  background: #e5e7eb;
  border-radius: 12px;
  overflow: hidden;
}

.bar-fill {
  height: 100%;
  border-radius: 12px;
  transition: width 0.5s ease-out;
}

.bar-fill.protein {
  background: linear-gradient(90deg, #ef4444 0%, #dc2626 100%);
}

.bar-fill.hydration {
  background: linear-gradient(90deg, #3b82f6 0%, #2563eb 100%);
}

.bar-fill.calories {
  background: linear-gradient(90deg, #f59e0b 0%, #d97706 100%);
}

.bar-fill.vitamins {
  background: linear-gradient(90deg, #22c55e 0%, #16a34a 100%);
}

.bar-fill.minerals {
  background: linear-gradient(90deg, #a855f7 0%, #9333ea 100%);
}

.nutrition-value {
  text-align: right;
  font-weight: bold;
  color: #6b7280;
}

.details-section {
  padding: 2rem;
  background: #f9fafb;
}

.details-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
  gap: 1rem;
}

.detail-item {
  background: white;
  padding: 1rem;
  border-radius: 8px;
  display: flex;
  flex-direction: column;
  border: 2px solid #e5e7eb;
}

.detail-label {
  font-size: 0.85rem;
  color: #6b7280;
  margin-bottom: 0.25rem;
}

.detail-value {
  font-size: 1.2rem;
  font-weight: bold;
  color: #1f2937;
}

.allergies-section {
  padding: 2rem;
}

.allergies-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
}

.allergy-tag {
  background: #fef3c7;
  color: #92400e;
  padding: 0.5rem 1rem;
  border-radius: 16px;
  font-size: 0.9rem;
  font-weight: 600;
  border: 2px solid #fbbf24;
}

.discovery-info {
  padding: 1.5rem 2rem;
  background: #f0fdf4;
  border-top: 2px solid #bbf7d0;
  text-align: center;
}

.discovery-text {
  margin: 0;
  color: #166534;
  font-size: 0.95rem;
  font-weight: 600;
}
</style>
