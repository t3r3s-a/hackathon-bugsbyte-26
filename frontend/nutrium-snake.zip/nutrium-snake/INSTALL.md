# 📥 INSTALAÇÃO - Nutrium Snake

## 🚀 Setup Rápido (3 Passos)

### 1️⃣ Descompactar

```bash
unzip nutrium-snake.zip
cd nutrium-snake
```

### 2️⃣ Instalar

```bash
npm install
```

### 3️⃣ Correr

```bash
npm run dev
```

Abrir: http://localhost:5173

✨ **Pronto!** O sistema de catálogo já está funcionando!

---

## 📦 O Que Foi Incluído

### ✅ COMPLETO E FUNCIONAL:

#### 📚 Sistema de Catálogo
- `FoodCatalog.vue` - Catálogo completo com filtros
- `FoodDetailModal.vue` - Modal com info nutricional
- `FoodDiscoveryToast.vue` - Notificação de descoberta
- `FoodDiscoverySystem.ts` - Sistema de descoberta com localStorage

#### 📊 Dados
- `foods.json` - 112 alimentos com dados completos
- `phases.json` - 5 fases do dia configuradas
- `types.ts` - Tipos TypeScript completos

#### 📖 Documentação
- `README.md` - Documentação completa
- `QUICKSTART.md` - Início rápido com exemplos
- `IMPLEMENTATION_GUIDE.md` - Guia do jogo principal
- `ASSETS_GUIDE.md` - Guia de imagens

### 🔧 PARA IMPLEMENTAR:

#### 🎮 Jogo Principal
- `MainSnakeGame.ts` - Jogo da cobra (ver IMPLEMENTATION_GUIDE.md)
- `GameContainer.vue` - Container do jogo
- `GameCanvas.vue` - Canvas principal

#### 🎯 Mini-jogos
- `SnakeJumpGame.ts` - Já criado anteriormente
- `BalanceGame.ts` - Já criado anteriormente  
- `RunningGame.ts` - Para criar

---

## 🎯 Como Usar Agora

### Testar Sistema de Catálogo

```vue
<!-- test-catalog.vue -->
<template>
  <div>
    <button @click="show = true">Abrir Catálogo</button>
    <button @click="testDiscovery">Descobrir Maçã</button>
    
    <FoodCatalog
      v-if="show"
      :foods="foods"
      @close="show = false"
    />
    
    <FoodDiscoveryToast
      v-if="discovered"
      :food-name="discovered.nome"
      :description="discovered.descricao"
      :color="discovered.cor"
      @close="discovered = null"
    />
  </div>
</template>

<script setup>
import { ref } from 'vue';
import FoodCatalog from '@/components/FoodCatalog.vue';
import FoodDiscoveryToast from '@/components/FoodDiscoveryToast.vue';
import { getFoodDiscoverySystem } from '@/games/FoodDiscoverySystem';
import foods from '@/data/foods.json';

const show = ref(false);
const discovered = ref(null);
const discovery = getFoodDiscoverySystem();

function testDiscovery() {
  const maca = foods.find(f => f.nome === 'Maçã');
  const isNew = discovery.discoverFood('Maçã');
  
  if (isNew) {
    discovered.value = maca;
  }
}
</script>
```

### Ver Alimentos Descobertos

```typescript
import { getFoodDiscoverySystem } from '@/games/FoodDiscoverySystem';

const discovery = getFoodDiscoverySystem();

// Total descoberto
console.log(discovery.getTotalDiscovered());

// Todos os descobertos
console.log(discovery.getAllDiscoveries());

// Resetar (debug)
discovery.resetAllDiscoveries();
```

---

## 📁 Estrutura Final

```
nutrium-snake/
├── 📖 README.md                    ⭐ LER PRIMEIRO
├── 🚀 QUICKSTART.md               ⭐ EXEMPLOS RÁPIDOS
├── 🔧 IMPLEMENTATION_GUIDE.md     ⭐ IMPLEMENTAR JOGO
├── 🖼️ ASSETS_GUIDE.md             
├── 📋 INSTALL.md (este ficheiro)
├── 📦 package.json
│
├── games/
│   ├── types.ts                   ✅ COMPLETO
│   ├── FoodDiscoverySystem.ts     ✅ COMPLETO
│   └── index.ts
│
├── components/
│   ├── FoodCatalog.vue            ✅ COMPLETO
│   ├── FoodDetailModal.vue        ✅ COMPLETO
│   ├── FoodDiscoveryToast.vue     ✅ COMPLETO
│   └── index.ts
│
├── data/
│   ├── foods.json                 ✅ 112 alimentos
│   └── phases.json                ✅ 5 fases
│
└── App.vue                         ✅ Exemplo completo
```

---

## 🎓 Próximos Passos

### 1. Testar Catálogo (5min)
Copie o código de teste acima e experimente!

### 2. Implementar Jogo Principal (2-3h)
Siga o `IMPLEMENTATION_GUIDE.md` - tem código completo!

### 3. Adicionar Imagens (1-2h)
Consulte `ASSETS_GUIDE.md` para obter/criar imagens

### 4. Mini-jogos (1h cada)
Use os já criados anteriormente ou crie novos

---

## 💡 Dicas

### Debug do Sistema de Descoberta

```typescript
// No browser console
const discovery = getFoodDiscoverySystem();

// Ver progresso
console.log(discovery.getTotalDiscovered()); // número

// Simular descoberta
discovery.discoverFood('Banana');
discovery.discoverFood('Maçã');

// Ver todas
console.log(discovery.getAllDiscoveries());

// Resetar tudo
discovery.resetAllDiscoveries();
```

### Ver Dados

```typescript
import foods from '@/data/foods.json';
import phases from '@/data/phases.json';

console.log(foods.length);     // 112 alimentos
console.log(phases.fase1.name); // "Pequeno-Almoço"
```

### Testar sem Jogo

O sistema de catálogo funciona **independentemente** do jogo!
Pode testar agora mesmo enquanto implementa o resto.

---

## ❓ Ajuda

### Erro: "Cannot find module"
```bash
# Verificar aliases no vite.config.ts
npm run dev
```

### Catálogo não abre
```vue
<!-- Verificar se importou corretamente -->
import FoodCatalog from '@/components/FoodCatalog.vue';
```

### Descobertas não salvam
- LocalStorage precisa estar ativo
- Não usar modo privado/incógnito

### Imagens não aparecem
- São opcionais! O jogo funciona sem elas
- Consulte ASSETS_GUIDE.md para adicionar

---

## 📚 Documentação

- **README.md**: Visão geral completa
- **QUICKSTART.md**: Exemplos prontos a usar
- **IMPLEMENTATION_GUIDE.md**: Como implementar jogo principal
- **ASSETS_GUIDE.md**: Como obter/criar imagens

---

## ✨ Features Principais

🎮 **Jogo Educacional de Nutrição**
- 5 refeições ao longo do dia
- 112 alimentos com dados reais
- Sistema de calorias dinâmico

📚 **Sistema de Catálogo** (COMPLETO!)
- Descoberta progressiva de alimentos
- Informação nutricional detalhada
- Barras visuais de nutrientes
- Avaliação com estrelas
- Filtros por cor de saúde
- Persistência em localStorage

🎯 **Mini-jogos entre refeições**
- Corrida, Salto, Equilíbrio
- Queima de calorias extra

---

**Desenvolvido com ❤️ para tornar a nutrição divertida!** 🐍🍎

Qualquer dúvida, consulte a documentação ou os exemplos! 📖✨
