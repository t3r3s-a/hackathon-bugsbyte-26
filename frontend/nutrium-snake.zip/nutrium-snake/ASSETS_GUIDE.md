# 📦 Guia de Assets (Imagens e Recursos)

## Estrutura de Pastas

```
public/
└── assets/
    ├── foods/              # Imagens dos alimentos
    │   ├── Maçã.png
    │   ├── Banana.png
    │   ├── Laranja (fruta).png
    │   └── ... (112 ficheiros)
    │
    └── sprites/            # Sprites do jogo
        ├── cabeca_snake.png
        ├── background_phase1.png
        ├── background_phase2.png
        ├── background_phase3.png
        ├── background_phase4.png
        └── background_phase5.png
```

## Imagens dos Alimentos

### Requisitos
- **Formato**: PNG com transparência
- **Tamanho**: 200x200px (recomendado)
- **Peso**: < 100KB cada
- **Naming**: Nome exato do alimento como em `foods.json`

### Lista Completa (112 alimentos)

#### Pequeno-Almoço / Lanches
```
Maçã.png
Banana.png
Laranja (fruta).png
Sumo de laranja (natural).png
Sumo de maçã (natural).png
Morangos.png
Framboesa.png
Kiwi.png
Pera.png
Leite integral.png
Leite magro.png
Leite de amêndoa (sem açúcar, comercial).png
Leite de soja (sem açúcar).png
Iogurte natural (inteiro).png
Iogurte grego (integral).png
Café preto (sem açúcar).png
Chá preto (preparado).png
Café com leite.png
Chocolate quente (com leite).png
Smoothie de morango (média).png
Aveia (flocos, seca).png
Papas de aveia (cozidas).png
Cereal instantâneo de aveia (preparado).png
Cereais flocos (cornflakes).png
Granola (com FRUTAS secos e mel).png
Muesli (sem açúcar).png
Pão integral.png
Pão branco.png
Bagel (simples).png
Bagel integral com sementes.png
Croissant.png
Torrada com tomate (preparado).png
Panquecas (cozidas, simples).png
Panqueca de aveia com banana.png
Crepe simples.png
Waffle.png
Muffin de mirtilo.png
Xarope de bordo (maple syrup).png
Mel (apicultura).png
Manteiga (normal).png
Manteiga de amendoim (cremosa).png
Nozes (mistura: noz, amêndoa, avelã) — FRUTAS secos.png
Amêndoas cruas.png
Amendoim torrado sem sal.png
Sementes de chia.png
Abacate.png
Queijo fresco (cottage).png
Queijo mozzarella.png
Fiambre|Presunto cozido.png
Bacon (frito).png
Salmão fumado.png
Ovo cozido (sem casca).png
Ovo estrelado (frito).png
```

#### Almoço / Jantar
```
Peito de frango grelhado (sem pele).png
Bife de vaca grelhado.png
Bife de porco grelhado.png
Peito de peru assado.png
Salmão grelhado.png
Truta grelhada.png
Bacalhau cozido.png
Lombinho de bacalhau salgado (dessalgado).png
Atum enlatado (em água, escorrido).png
Sardinha enlatada em óleo.png
Camarão cozido.png
Carne picada (vacuno, cozida, magra).png
Quibe assado (carne e bulgur).png
Falafel (sem tahine).png
Hambúrguer de leguminosas.png
Tofu firme.png
Tofu fumado.png
Tempeh.png
Quinoa cozida.png
Arroz integral cozido.png
Arroz branco cozido.png
Massa cozida (trigo).png
Polenta cozida.png
Puré de batata.png
Batata doce assada.png
Feijão cozido (feijão preto).png
Lentilhas cozidas.png
Grão-de-bico cozido.png
Húmus (com tahine).png
Molho de tomate (caseiro).png
Salada de folhas (mix).png
Brócolos cozidos.png
Espinafres cozidos.png
Cenoura crua.png
Tomate (cru).png
Tomate cherry.png
Pepino.png
Berinjela grelhada.png
Curgete grelhada.png
Cogumelos (champignon, cozidos).png
Ervilhas cozidas.png
Milho cozido.png
Pão integral.png (duplicado)
Pão de centeio.png
Bagel integral com sementes.png (duplicado)
Pão pita.png
Queijo fresco (cottage).png (duplicado)
Queijo mozzarella.png (duplicado)
Azeitonas (pretas).png
Azeite extra virgem.png
Água.png
```

## Como Criar/Obter Imagens

### Opção 1: Gerar com IA
```
Prompt para Midjourney/DALL-E:
"professional food photography of [ALIMENTO], 
top view, white background, high quality, 
natural lighting, appetizing, isolated"
```

### Opção 2: Sites Gratuitos
- **Unsplash**: unsplash.com/food
- **Pexels**: pexels.com/search/food
- **Pixabay**: pixabay.com/images/search/food

### Opção 3: Criar Ícones
- **Flaticon**: flaticon.com
- **Noun Project**: thenounproject.com
- **Font Awesome**: fontawesome.com (usar como fallback)

## Processamento de Imagens

### Com ImageMagick
```bash
# Redimensionar para 200x200
convert input.png -resize 200x200 -background none -gravity center -extent 200x200 output.png

# Otimizar tamanho
pngquant --quality=65-80 --ext .png --force *.png
```

### Com Python (Pillow)
```python
from PIL import Image

img = Image.open('input.png')
img = img.resize((200, 200), Image.LANCZOS)
img.save('output.png', optimize=True)
```

## Fallback (Sem Imagens)

O jogo funciona perfeitamente sem imagens!
- Usa cores sólidas baseadas no tipo de alimento
- Emoji como placeholder: 🍽️
- Ainda mostra todas as informações nutricionais

```typescript
// No código
if (!imageAvailable) {
  // Desenha cor + emoji
  ctx.fillStyle = COLOR_MAP[food.cor];
  ctx.fillRect(x, y, size, size);
  ctx.font = '48px serif';
  ctx.fillText('🍽️', x, y);
}
```

## Sprites do Jogo

### cabeca_snake.png
- **Tamanho**: 64x64px
- **Descrição**: Cabeça da cobra (virada para a direita)
- **Formato**: PNG com transparência

### Fundos das Fases
- **Tamanho**: 900x720px (ou resolução do jogo)
- **Formato**: PNG ou JPG
- **Nomes**:
  - `background_phase1.png` (Pequeno-almoço)
  - `background_phase2.png` (Lanche manhã)
  - `background_phase3.png` (Almoço)
  - `background_phase4.png` (Lanche tarde)
  - `background_phase5.png` (Jantar)

## Performance

### Otimização
- Use sprites compilados quando possível
- Pré-carregue todas as imagens no início
- Cache imagens redimensionadas
- Use WebP se o browser suportar

### Exemplo de Pré-carregamento
```typescript
async function preloadFoodImages(foods: Food[]): Promise<void> {
  const promises = foods.map(food => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = resolve;
      img.onerror = resolve; // Continua mesmo com erro
      img.src = `/assets/foods/${food.nome}.png`;
    });
  });
  
  await Promise.all(promises);
}
```

## Licenças

### Importante
- ✅ Use apenas imagens com licença adequada
- ✅ Atribua créditos quando necessário
- ✅ Verifique licenças comerciais vs não-comerciais
- ❌ Não use imagens protegidas por copyright

### Recomendações
- **Pexels**: Licença gratuita para uso comercial
- **Unsplash**: Licença gratuita
- **Pixabay**: Licença Pixabay
- **Flaticon**: Atribuição necessária (plano gratuito)

## Testing sem Imagens

Para testar o jogo sem todas as imagens:

```typescript
// Modo de desenvolvimento
const DEV_MODE = true;

if (DEV_MODE) {
  // Usar apenas cores e emojis
  drawFoodPlaceholder(food);
} else {
  // Tentar carregar imagem real
  drawFoodImage(food);
}
```

## Checklist

- [ ] 112 imagens de alimentos (200x200px)
- [ ] Imagem cabeça cobra (64x64px)
- [ ] 5 fundos de fases (900x720px)
- [ ] Todas otimizadas (< 100KB cada)
- [ ] Testado fallback sem imagens
- [ ] Verificadas licenças

## Dicas

1. **Consistência**: Mantém o mesmo estilo visual
2. **Qualidade**: Prefere qualidade a quantidade
3. **Tamanho**: Otimiza sempre antes de usar
4. **Naming**: Usa nomes exatos do JSON
5. **Formato**: PNG para transparência, JPG para fundos

---

**Nota**: O sistema funciona perfeitamente mesmo sem imagens! 
As imagens são um enhancement, não um requirement.
