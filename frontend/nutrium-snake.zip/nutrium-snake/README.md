# 🐍 Nutrium Snake - Jogo Educacional de Nutrição

Um jogo educacional onde aprendes sobre alimentação saudável enquanto jogas! Come alimentos durante o dia, descobre novos alimentos na tua **Caderneta Alimentar**, e joga mini-jogos entre refeições.

## 🎮 Sobre o Jogo

### Conceito
És uma cobra que precisa comer ao longo do dia (5 refeições):
1. 🌅 Pequeno-Almoço
2. ☕ Lanche da Manhã  
3. 🍽️ Almoço
4. 🥤 Lanche da Tarde
5. 🌙 Jantar

### Objetivos
- ⚖️ Manter calorias entre 0 e 2500
- 🎯 Sobreviver até ao fim do dia
- 📚 Descobrir todos os 112 alimentos
- 🏃 Ganhar mini-jogos para queimar calorias

### Sistema de Calorias
- **Inicial**: 300 kcal
- **Perdes** 5 kcal/segundo automaticamente
- **Ganhas** calorias ao comer alimentos
- **Tamanho da cobra**: 1 segmento por cada 100 kcal

## 📚 Novo Sistema de Catálogo

### Caderneta Alimentar
Cada vez que comes um alimento pela primeira vez:
- ✨ Pop-up elegante aparece (não um alert!)
- 📖 Alimento é adicionado à tua caderneta
- 🔓 Desbloqueia visualização completa do alimento

### Informações do Alimento
Cada alimento mostra:
- 📊 **Barras Nutricionais** (0-5):
  - 💪 Proteínas
  - 💧 Hidratação
  - 🔥 Calorias
  - 🍊 Vitaminas
  - ⚡ Minerais
  
- 🌟 **Avaliação** (1-5 estrelas)
- 🔬 **Detalhes Nutricionais** completos
- ⚠️ **Alergénios**
- 📝 **Descrição educacional**
- 🎨 **Cor de Saúde**:
  - 🟢 Verde = Saudável (come regularmente)
  - 🟡 Amarelo = Moderado (com cautela)
  - 🟠 Laranja = Ocasional (raramente)
  - 🔴 Vermelho = Evitar

### Progresso
- Contador de alimentos descobertos (X/112)
- Filtros por cor de saúde
- Quantas vezes comeste cada alimento
- Data de primeira descoberta

## 🎯 Mini-jogos

Entre refeições, escolhe:
- **🏃 Corrida**: Alterna setinhas ← → para correr
- **🦖 Cobra Saltadora**: Salta obstáculos com espaço
- **⚖️ Equilíbrio**: Mantém equilíbrio com ← →

Ganhar mini-jogos = queima calorias extra!

## 📂 Estrutura do Projeto

```
nutrium-snake/
├── games/                          # Lógica TypeScript
│   ├── types.ts                    # Tipos do jogo
│   ├── FoodDiscoverySystem.ts      # Sistema de descoberta
│   ├── MainSnakeGame.ts            # Jogo principal
│   ├── SnakeJumpGame.ts            # Mini-jogo salto
│   ├── BalanceGame.ts              # Mini-jogo equilíbrio
│   ├── RunningGame.ts              # Mini-jogo corrida
│   └── GameManager.ts              # Gerenciador
│
├── components/                     # Componentes Vue
│   ├── GameCanvas.vue              # Canvas principal
│   ├── FoodCatalog.vue             # Catálogo de alimentos ⭐
│   ├── FoodDetailModal.vue         # Modal de detalhes ⭐
│   ├── FoodDiscoveryToast.vue      # Notificação descoberta ⭐
│   ├── PhaseTransition.vue         # Transição entre fases
│   └── GameContainer.vue           # Container principal
│
├── data/                           # Dados JSON
│   ├── foods.json                  # 112 alimentos
│   └── phases.json                 # Configuração fases
│
└── assets/                         # Recursos
    ├── foods/                      # Imagens alimentos
    │   ├── Maçã.png
    │   ├── Banana.png
    │   └── ...
    └── sprites/                    # Sprites jogo
        └── cabeca_snake.png
```

## 🚀 Como Usar

### 1. Instalação

```bash
npm install
```

### 2. Uso Básico

```vue
<template>
  <div id="app">
    <!-- Jogo Principal -->
    <GameContainer
      @food-discovered="handleFoodDiscovery"
      @catalog-open="showCatalog = true"
    />

    <!-- Catálogo (aberto com tecla C ou botão) -->
    <FoodCatalog
      v-if="showCatalog"
      :foods="allFoods"
      @close="showCatalog = false"
    />

    <!-- Toast de Descoberta -->
    <FoodDiscoveryToast
      v-if="discoveredFood"
      :food-name="discoveredFood.nome"
      :description="discoveredFood.descricao"
      :color="discoveredFood.cor"
      @close="discoveredFood = null"
    />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import GameContainer from '@/components/GameContainer.vue';
import FoodCatalog from '@/components/FoodCatalog.vue';
import FoodDiscoveryToast from '@/components/FoodDiscoveryToast.vue';
import allFoods from '@/data/foods.json';
import type { Food } from '@/games/types';

const showCatalog = ref(false);
const discoveredFood = ref<Food | null>(null);

function handleFoodDiscovery(food: Food) {
  discoveredFood.value = food;
}
</script>
```

### 3. Configuração do Vite

```typescript
// vite.config.ts
import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url))
    }
  }
});
```

## 🎮 Controles

### Jogo Principal
- **← → ↑ ↓**: Mover cobra
- **C**: Abrir catálogo
- **ESC**: Pausar
- **Enter**: Confirmar opções

### Mini-jogos
- **Corrida**: Alterna ← e → rapidamente
- **Salto**: Barra de espaço
- **Equilíbrio**: ← e → para balancear

## 📊 Sistema de Descoberta

### Como Funciona

```typescript
import { getFoodDiscoverySystem } from '@/games/FoodDiscoverySystem';

const discovery = getFoodDiscoverySystem();

// Quando come um alimento
function eatFood(foodName: string) {
  const isNew = discovery.discoverFood(foodName);
  
  if (isNew) {
    // Mostrar toast de descoberta!
    showDiscoveryToast(foodName);
  }
}

// Ver se já descobriu
const hasDiscovered = discovery.isDiscovered('Maçã'); // boolean

// Total descoberto
const total = discovery.getTotalDiscovered(); // número

// Obter todas descobertas
const all = discovery.getAllDiscoveries(); // array
```

### Persistência
- Usa **localStorage** automaticamente
- Progresso salvo entre sessões
- Reset opcional para debug

## 🎨 Personalização

### Cores dos Alimentos

```typescript
import { COLOR_MAP } from '@/games/types';

// Cores disponíveis
COLOR_MAP.verde    // #22C55E (saudável)
COLOR_MAP.amarelo  // #FDE047 (moderado)
COLOR_MAP.laranja  // #FB923C (ocasional)
COLOR_MAP.vermelho // #EF4444 (evitar)
```

### Constantes do Jogo

```typescript
import { GAME_CONSTANTS } from '@/games/types';

// Modificar constantes
GAME_CONSTANTS.CANVAS_WIDTH = 1200;
GAME_CONSTANTS.CALORIES_PER_SECOND = 3;
GAME_CONSTANTS.CALORIES_MAX = 3000;
```

### Fases/Refeições

Editar `data/phases.json`:

```json
{
  "fase1": {
    "id": "fase1",
    "name": "Pequeno-Almoço",
    "duration": 10,
    "cols": 20,
    "rows": 16,
    "foodList": [...],
    "bgColor": "#4682B4"
  }
}
```

## 📱 Responsividade

O jogo adapta-se automaticamente:
- Desktop: 900x800px
- Tablet: Escala proporcional
- Mobile: Interface otimizada

## 🎯 Recursos Avançados

### 1. Barras Nutricionais Dinâmicas

```typescript
const bars = discovery.calculateNutritionBars(food);
// Retorna: { protein: 0-5, hydration: 0-5, ... }
```

### 2. Avaliação Automática

```typescript
const rating = discovery.calculateRating(food);
// Retorna estrelas de 1-5
```

### 3. Filtros por Categoria

```vue
<FoodCatalog
  :foods="allFoods"
  :initial-filter="'verde'"
/>
```

### 4. Exportar Progresso

```typescript
const json = discovery.exportToJSON();
console.log(json); // JSON com todas descobertas
```

## 🐛 Troubleshooting

### Imagens não aparecem
- Coloque as imagens em `public/assets/foods/`
- Nome do ficheiro deve ser exatamente igual ao nome do alimento
- Formato: `.png`

### Descobertas não salvam
- Verifique se localStorage está ativo no browser
- Desative modo privado/incógnito

### Canvas não renderiza
- Certifique-se que o elemento canvas tem dimensões
- Verifique console para erros

### Performance baixa
- Reduza o número de segmentos (menos calorias)
- Diminua tamanho da grid nas fases
- Use imagens otimizadas (< 100KB cada)

## 📚 Dados Nutricionais

### Fonte dos Dados
Os 112 alimentos incluem:
- Frutas, vegetais, cereais
- Laticínios, carnes, peixes
- Leguminosas, frutos secos
- Bebidas

### Informações por Alimento
- ✅ Energia (kcal)
- ✅ Macronutrientes (proteínas, hidratos, lípidos, açúcares)
- ✅ Micronutrientes (vitaminas A e C, minerais)
- ✅ Água
- ✅ Alergénios
- ✅ Descrição educacional

## 🎓 Aspetos Educacionais

### Objetivos Pedagógicos
1. **Literacia nutricional**: Aprender valores de alimentos
2. **Equilíbrio calórico**: Entender balanço energético
3. **Variedade alimentar**: Descobrir 112 alimentos
4. **Leitura de rótulos**: Interpretar informação nutricional
5. **Escolhas saudáveis**: Sistema de cores

### Público-alvo
- Crianças (7+ anos)
- Adolescentes
- Adultos que querem aprender nutrição
- Professores (recurso educativo)

## 🔄 Futuras Melhorias

- [ ] Modo multiplayer
- [ ] Mais mini-jogos
- [ ] Conquistas/badges
- [ ] Ranking online
- [ ] Sugestões de refeições
- [ ] Partilha nas redes sociais
- [ ] Sons e música
- [ ] Animações melhoradas
- [ ] Modo tutorial
- [ ] Múltiplos idiomas

## 📄 Licença

Este projeto é open-source e pode ser usado livremente para fins educacionais.

## 🤝 Contribuir

Contribuições são bem-vindas:
1. Fork o projeto
2. Cria uma branch (`git checkout -b feature/NovaFeature`)
3. Commit mudanças (`git commit -m 'Add NovaFeature'`)
4. Push para branch (`git push origin feature/NovaFeature`)
5. Abre Pull Request

## 📧 Suporte

Para dúvidas ou problemas:
- Consulta este README
- Verifica exemplos no código
- Abre uma issue no repositório

---

Desenvolvido com ❤️ para tornar a nutrição divertida! 🐍🍎
