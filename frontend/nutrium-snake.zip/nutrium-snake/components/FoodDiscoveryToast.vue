<template>
  <Teleport to="body">
    <Transition name="toast">
      <div v-if="visible" class="discovery-toast" @click="hide">
        <div class="toast-content">
          <div class="toast-icon">🎉</div>
          <div class="toast-text">
            <h3 class="toast-title">Novo Alimento Descoberto!</h3>
            <p class="toast-food-name">{{ foodName }}</p>
            <p class="toast-description">{{ description }}</p>
          </div>
          <div class="toast-image">
            <img
              v-if="!imageError"
              :src="`/assets/foods/${foodName}.png`"
              :alt="foodName"
              @error="imageError = true"
            />
            <div v-if="imageError" class="image-placeholder" :style="{ background: color }">
              🍽️
            </div>
          </div>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" :style="{ width: `${progress}%` }"></div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, watch, onMounted } from 'vue';
import { COLOR_MAP } from '../games/types';

interface Props {
  foodName: string;
  description: string;
  color: keyof typeof COLOR_MAP;
  duration?: number; // Em milissegundos
}

const props = withDefaults(defineProps<Props>(), {
  duration: 5000
});

const emit = defineEmits<{
  close: [];
}>();

const visible = ref(false);
const progress = ref(100);
const imageError = ref(false);
let intervalId: number | null = null;

onMounted(() => {
  // Pequeno delay para a animação funcionar
  setTimeout(() => {
    visible.value = true;
    startProgress();
  }, 100);
});

function startProgress() {
  const steps = props.duration / 50; // Atualiza a cada 50ms
  const decrement = 100 / steps;
  
  intervalId = window.setInterval(() => {
    progress.value -= decrement;
    if (progress.value <= 0) {
      hide();
    }
  }, 50);
}

function hide() {
  visible.value = false;
  if (intervalId !== null) {
    clearInterval(intervalId);
  }
  setTimeout(() => {
    emit('close');
  }, 300); // Espera animação de saída
}

// Limpar intervalo ao destruir componente
watch(() => visible.value, (newVal) => {
  if (!newVal && intervalId !== null) {
    clearInterval(intervalId);
  }
});
</script>

<style scoped>
.discovery-toast {
  position: fixed;
  top: 20px;
  right: 20px;
  width: 400px;
  background: white;
  border-radius: 16px;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  cursor: pointer;
  z-index: 9999;
  animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
  from {
    transform: translateX(450px);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

.toast-content {
  display: flex;
  gap: 1rem;
  padding: 1.5rem;
  align-items: center;
}

.toast-icon {
  font-size: 3rem;
  animation: bounce 0.6s ease-out;
}

@keyframes bounce {
  0%, 100% {
    transform: scale(1);
  }
  50% {
    transform: scale(1.2);
  }
}

.toast-text {
  flex: 1;
}

.toast-title {
  margin: 0 0 0.5rem 0;
  font-size: 1.1rem;
  color: #1f2937;
  font-weight: bold;
}

.toast-food-name {
  margin: 0 0 0.5rem 0;
  font-size: 1.3rem;
  color: #4f46e5;
  font-weight: bold;
}

.toast-description {
  margin: 0;
  font-size: 0.9rem;
  color: #6b7280;
  line-height: 1.4;
}

.toast-image {
  width: 80px;
  height: 80px;
  border-radius: 12px;
  overflow: hidden;
  flex-shrink: 0;
}

.toast-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.image-placeholder {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 3rem;
}

.progress-bar {
  height: 4px;
  background: #e5e7eb;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #4f46e5 0%, #7c3aed 100%);
  transition: width 0.05s linear;
}

/* Transição Vue */
.toast-enter-active,
.toast-leave-active {
  transition: all 0.3s ease;
}

.toast-enter-from {
  transform: translateX(450px);
  opacity: 0;
}

.toast-leave-to {
  transform: translateX(450px) scale(0.8);
  opacity: 0;
}

/* Responsividade */
@media (max-width: 500px) {
  .discovery-toast {
    width: calc(100vw - 40px);
    right: 20px;
  }
}
</style>
